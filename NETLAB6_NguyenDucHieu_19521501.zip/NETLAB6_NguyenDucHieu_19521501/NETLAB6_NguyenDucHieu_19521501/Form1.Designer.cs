﻿
namespace NETLAB6_NguyenDucHieu_19521501
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpLoad = new FontAwesome.Sharp.IconButton();
            this.btnDownLoad = new FontAwesome.Sharp.IconButton();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.pnPassword = new System.Windows.Forms.Panel();
            this.pnUser = new System.Windows.Forms.Panel();
            this.lbPassword = new System.Windows.Forms.Label();
            this.ListBox1 = new System.Windows.Forms.ListBox();
            this.lbUser = new System.Windows.Forms.Label();
            this.txtIpServer = new System.Windows.Forms.TextBox();
            this.pnIP = new System.Windows.Forms.Panel();
            this.lbIP = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lbProcess = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnUpLoad
            // 
            this.btnUpLoad.FlatAppearance.BorderSize = 0;
            this.btnUpLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpLoad.IconChar = FontAwesome.Sharp.IconChar.Upload;
            this.btnUpLoad.IconColor = System.Drawing.Color.OrangeRed;
            this.btnUpLoad.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnUpLoad.Location = new System.Drawing.Point(737, 12);
            this.btnUpLoad.Name = "btnUpLoad";
            this.btnUpLoad.Size = new System.Drawing.Size(108, 47);
            this.btnUpLoad.TabIndex = 1;
            this.btnUpLoad.UseVisualStyleBackColor = true;
            this.btnUpLoad.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // btnDownLoad
            // 
            this.btnDownLoad.FlatAppearance.BorderSize = 0;
            this.btnDownLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDownLoad.IconChar = FontAwesome.Sharp.IconChar.Download;
            this.btnDownLoad.IconColor = System.Drawing.Color.Lime;
            this.btnDownLoad.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnDownLoad.Location = new System.Drawing.Point(851, 12);
            this.btnDownLoad.Name = "btnDownLoad";
            this.btnDownLoad.Size = new System.Drawing.Size(105, 47);
            this.btnDownLoad.TabIndex = 2;
            this.btnDownLoad.UseVisualStyleBackColor = true;
            this.btnDownLoad.Click += new System.EventHandler(this.iconButton2_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.SystemColors.Control;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPassword.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(147, 171);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(288, 40);
            this.txtPassword.TabIndex = 32;
            this.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtUser
            // 
            this.txtUser.BackColor = System.Drawing.SystemColors.Control;
            this.txtUser.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUser.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUser.Location = new System.Drawing.Point(147, 105);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(288, 40);
            this.txtUser.TabIndex = 31;
            this.txtUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // iconButton3
            // 
            this.iconButton3.FlatAppearance.BorderSize = 0;
            this.iconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.Eraser;
            this.iconButton3.IconColor = System.Drawing.Color.OrangeRed;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.Location = new System.Drawing.Point(441, 12);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(50, 47);
            this.iconButton3.TabIndex = 36;
            this.iconButton3.UseVisualStyleBackColor = true;
            this.iconButton3.Click += new System.EventHandler(this.iconButton3_Click);
            // 
            // pnPassword
            // 
            this.pnPassword.BackColor = System.Drawing.Color.OrangeRed;
            this.pnPassword.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnPassword.Location = new System.Drawing.Point(20, 215);
            this.pnPassword.Name = "pnPassword";
            this.pnPassword.Size = new System.Drawing.Size(415, 3);
            this.pnPassword.TabIndex = 29;
            // 
            // pnUser
            // 
            this.pnUser.BackColor = System.Drawing.Color.OrangeRed;
            this.pnUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnUser.Location = new System.Drawing.Point(20, 145);
            this.pnUser.Name = "pnUser";
            this.pnUser.Size = new System.Drawing.Size(415, 3);
            this.pnUser.TabIndex = 26;
            // 
            // lbPassword
            // 
            this.lbPassword.AutoSize = true;
            this.lbPassword.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassword.ForeColor = System.Drawing.Color.OrangeRed;
            this.lbPassword.Location = new System.Drawing.Point(15, 182);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(119, 26);
            this.lbPassword.TabIndex = 30;
            this.lbPassword.Text = "Password:";
            // 
            // ListBox1
            // 
            this.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ListBox1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListBox1.FormattingEnabled = true;
            this.ListBox1.ItemHeight = 30;
            this.ListBox1.Location = new System.Drawing.Point(20, 263);
            this.ListBox1.Name = "ListBox1";
            this.ListBox1.Size = new System.Drawing.Size(945, 330);
            this.ListBox1.TabIndex = 3;
            this.ListBox1.SelectedIndexChanged += new System.EventHandler(this.ListBox1_SelectedIndexChanged);
            // 
            // lbUser
            // 
            this.lbUser.AutoSize = true;
            this.lbUser.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUser.ForeColor = System.Drawing.Color.OrangeRed;
            this.lbUser.Location = new System.Drawing.Point(15, 108);
            this.lbUser.Name = "lbUser";
            this.lbUser.Size = new System.Drawing.Size(126, 26);
            this.lbUser.TabIndex = 28;
            this.lbUser.Text = "Username:";
            this.lbUser.Click += new System.EventHandler(this.lbUser_Click);
            // 
            // txtIpServer
            // 
            this.txtIpServer.BackColor = System.Drawing.SystemColors.Control;
            this.txtIpServer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIpServer.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIpServer.Location = new System.Drawing.Point(128, 32);
            this.txtIpServer.Name = "txtIpServer";
            this.txtIpServer.Size = new System.Drawing.Size(307, 40);
            this.txtIpServer.TabIndex = 34;
            this.txtIpServer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtIpServer.TextChanged += new System.EventHandler(this.txtIpServer_TextChanged);
            // 
            // pnIP
            // 
            this.pnIP.BackColor = System.Drawing.Color.OrangeRed;
            this.pnIP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pnIP.Location = new System.Drawing.Point(20, 75);
            this.pnIP.Name = "pnIP";
            this.pnIP.Size = new System.Drawing.Size(415, 3);
            this.pnIP.TabIndex = 27;
            this.pnIP.Paint += new System.Windows.Forms.PaintEventHandler(this.pnIP_Paint);
            // 
            // lbIP
            // 
            this.lbIP.AutoSize = true;
            this.lbIP.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIP.ForeColor = System.Drawing.Color.OrangeRed;
            this.lbIP.Location = new System.Drawing.Point(15, 46);
            this.lbIP.Name = "lbIP";
            this.lbIP.Size = new System.Drawing.Size(107, 26);
            this.lbIP.TabIndex = 35;
            this.lbIP.Text = "IP Server:";
            this.lbIP.Click += new System.EventHandler(this.lbIP_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(147, 405);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(685, 41);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBar1.TabIndex = 37;
            // 
            // lbProcess
            // 
            this.lbProcess.AutoSize = true;
            this.lbProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProcess.Location = new System.Drawing.Point(485, 373);
            this.lbProcess.Name = "lbProcess";
            this.lbProcess.Size = new System.Drawing.Size(0, 29);
            this.lbProcess.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(632, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(338, 28);
            this.label1.TabIndex = 39;
            this.label1.Text = "Nguyễn Đức Hiếu - 19521501";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 605);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbProcess);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.iconButton3);
            this.Controls.Add(this.lbIP);
            this.Controls.Add(this.pnIP);
            this.Controls.Add(this.txtIpServer);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.pnPassword);
            this.Controls.Add(this.lbPassword);
            this.Controls.Add(this.pnUser);
            this.Controls.Add(this.lbUser);
            this.Controls.Add(this.ListBox1);
            this.Controls.Add(this.btnDownLoad);
            this.Controls.Add(this.btnUpLoad);
            this.Name = "Form1";
            this.Text = "FTP Client";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private FontAwesome.Sharp.IconButton btnUpLoad;
        private FontAwesome.Sharp.IconButton btnDownLoad;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUser;
        private FontAwesome.Sharp.IconButton iconButton3;
        private System.Windows.Forms.Panel pnPassword;
        private System.Windows.Forms.Panel pnUser;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.ListBox ListBox1;
        private System.Windows.Forms.Label lbUser;
        private System.Windows.Forms.TextBox txtIpServer;
        private System.Windows.Forms.Panel pnIP;
        private System.Windows.Forms.Label lbIP;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lbProcess;
        private System.Windows.Forms.Label label1;
    }
}

