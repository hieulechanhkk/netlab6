﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Threading;

namespace NETLAB6_NguyenDucHieu_19521501
{
    public partial class Form1 : Form
    {
        
        private FtpWebRequest ftpRequest = null;
        private FtpWebResponse ftpResponse = null;
        private Stream ftpStream = null;
        private int bufferSize = 2048;
        string file;

        public Form1()
        {
            InitializeComponent();
            ListBox1.Visible = false;
            progressBar1.Visible = false;
            lbProcess.Visible = false;

        }
      
      
        
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void upload()
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.ShowDialog();
                if (ofd.FileName == "")
                    return;
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://"+txtIpServer.Text + "/" + ofd.SafeFileName);
                request.Method = WebRequestMethods.Ftp.UploadFile;
                request.Credentials = new NetworkCredential(txtUser.Text,txtPassword.Text );
                request.KeepAlive = true;
                request.UseBinary = true;
                request.UsePassive = true;


                StreamReader reader = new StreamReader(ofd.FileName);
                byte[] data = Encoding.UTF8.GetBytes(reader.ReadToEnd());
                reader.Close();
                request.ContentLength = data.Length;
                Stream rqstream = request.GetRequestStream();
                rqstream.Write(data, 0, data.Length);
                rqstream.Close();

                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                lbProcess.Visible = true;
                progressBar1.Visible = true;
                WaitProcess();
                MessageBox.Show("Upload Completed!!!");
                lbProcess.Visible = false;
                progressBar1.Visible = false;
                response.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Login Fail!!!");
            }
        }

        private void download(string remoteFile, string pathsave)
        {
            try
            {
           
                ftpRequest = (FtpWebRequest)FtpWebRequest.Create("ftp://" +txtIpServer.Text+ "/" + remoteFile);
                ftpRequest.Credentials = new NetworkCredential(txtUser.Text, txtPassword.Text);
                ftpRequest.UseBinary = true;
                ftpRequest.UsePassive = true;
                ftpRequest.KeepAlive = true;
                ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
                ftpResponse = (FtpWebResponse)ftpRequest.GetResponse();
                ftpStream = ftpResponse.GetResponseStream();
                FileStream localFileStream = new FileStream(pathsave, FileMode.Create);
                byte[] byteBuffer = new byte[bufferSize];
                int bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                try
                {
                    while (bytesRead > 0)
                    {
                        localFileStream.Write(byteBuffer, 0, bytesRead);
                        bytesRead = ftpStream.Read(byteBuffer, 0, bufferSize);
                    }
                    ListBox1.Visible = false;
                    progressBar1.Visible = true;
                    lbProcess.Visible = true;
                    WaitProcess();
                }
                catch (Exception ex) { MessageBox.Show(ex.ToString()); }
                MessageBox.Show("Download completed!!!");
                ListBox1.Visible = true;
                progressBar1.Visible = false;
                lbProcess.Visible = false;
                localFileStream.Close();
                ftpStream.Close();
                ftpResponse.Close();
                ftpRequest = null;
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
            return;
        }
        private void listinfodetail()
        {
            try
            {
                FtpWebRequest Request = (FtpWebRequest)WebRequest.Create("ftp://" + txtIpServer.Text + "/");
                Request.Method = WebRequestMethods.Ftp.ListDirectory;
                Request.Credentials = new NetworkCredential(txtUser.Text, txtPassword.Text);
                FtpWebResponse Response = (FtpWebResponse)Request.GetResponse();
                Stream ResponseStream = Response.GetResponseStream();
                StreamReader Reader = new StreamReader(ResponseStream);

                ListBox1.Items.Add("File name");
                while (!Reader.EndOfStream)
                {
                    ListBox1.Items.Add(Reader.ReadLine().ToString());
                }
                Response.Close();
                ResponseStream.Close();
                Reader.Close();
                
            ListBox1.Visible = true;
            ListBox1.Enabled = true;
            }
            catch
            {
                MessageBox.Show("Fail Login!!!");
                return;
            }
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBox1.SelectedItems.Count == 0)
                return;
            string filename = ListBox1.SelectedItem.ToString();
            DialogResult dr = MessageBox.Show("Do you want to download " + filename + "!!!", "Thông báo", MessageBoxButtons.YesNo);
            if(dr==DialogResult.Yes)
            {
                FolderBrowserDialog fbd = new FolderBrowserDialog();
                fbd.ShowDialog();
                if (fbd.SelectedPath == "")
                    return;
                download(filename,fbd.SelectedPath+"/"+filename);
            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            ListBox1.Visible = false;
            if(txtIpServer.Text!=string.Empty && txtPassword.Text!=string.Empty&&txtUser.Text!=string.Empty)
                upload();
            else
            {
                MessageBox.Show("Fill your information!!!");
            }
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            /*FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.ShowDialog();*/
            listinfodetail();

        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            txtPassword.Text = string.Empty;
            txtUser.Text = string.Empty;
            txtIpServer.Text = string.Empty;
            ListBox1.Visible = false;
        }

        private void lbIP_Click(object sender, EventArgs e)
        {

        }

        private void txtIpServer_TextChanged(object sender, EventArgs e)
        {

        }

        private void pnIP_Paint(object sender, PaintEventArgs e)
        {

        }
        private void WaitProcess()
        {
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 2000;
            for(double i=0;i<=2000;i++)
            {
                lbProcess.Text = (i / 20).ToString() + "%";
                progressBar1.Value = (int)i;
            }
        }
        private void lbUser_Click(object sender, EventArgs e)
        {

        }
    }
}
